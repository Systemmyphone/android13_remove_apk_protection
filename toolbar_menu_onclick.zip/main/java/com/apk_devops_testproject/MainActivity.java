package com.apk_devops_testproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.item1:
                Toast toast=Toast.makeText(getApplicationContext(),"Item 1 Clicked",Toast.LENGTH_SHORT);
                toast.show();
                break;
            case R.id.item2:
                Toast toast1=Toast.makeText(getApplicationContext(),"Item 2 Clicked",Toast.LENGTH_SHORT);
                toast1.show();
                break;
            case R.id.item3:
                Toast toast2=Toast.makeText(getApplicationContext(),"Item 3 Clicked",Toast.LENGTH_SHORT);
                toast2.show();
                break;

        }
        return true;
    }

}
